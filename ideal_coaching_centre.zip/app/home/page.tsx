import React from 'react';

export default function WelcomePage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-gray-100 p-10 text-center border-b">
        <h1 className="text-4xl font-extrabold text-blue-800 underline">डैशबोर्ड: मुख्य सेक्शन</h1>
        <p className="mt-2 text-gray-500">यहाँ आप कोचिंग की विस्तृत जानकारी देख सकते हैं</p>
      </div>

      {/* Main Content Areas */}
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-10 p-10">
        <div className="bg-blue-50 p-8 rounded-3xl border-2 border-blue-200">
          <h2 className="text-2xl font-bold mb-4 text-blue-700">नवीनतम सूचनाएं (Notice Board)</h2>
          <ul className="list-disc ml-5 space-y-2 text-gray-700">
            <li>बैच 2026 का एडमिशन शुरू हो चुका है।</li>
            <li>नया बैच 2 फरवरी, 2026 से शुरू होगा।</li>
          </ul>
        </div>

        <div className="bg-orange-50 p-8 rounded-3xl border-2 border-orange-200">
          <h2 className="text-2xl font-bold mb-4 text-orange-700">हमारा विजन</h2>
          <p className="text-gray-700 leading-relaxed">
            हमारा उद्देश्य केवल किताबी ज्ञान देना नहीं, बल्कि छात्र का सर्वांगीण विकास करना है। 
            हम "अनुशासन और सच्चरित्रता" को ही सफलता की असली चाबी मानते हैं।
          </p>
        </div>
      </div>

      <div className="text-center mt-10">
        <a href="/" className="text-blue-600 font-bold hover:underline">← वापस मुख्य गेट पर जाएँ</a>
      </div>
      {/* --- ONLY TEACHERS SECTION START --- */}
<div style={{ backgroundColor: '#f4f7fa', padding: '60px 20px', fontFamily: 'sans-serif' }}>
  <div style={{ maxWidth: '1100px', margin: '0 auto', textAlign: 'center' }}>
    
    {/* Heading */}
    <h2 style={{ color: '#002147', fontSize: '32px', fontWeight: 'bold', marginBottom: '10px' }}>
      Meet Our Expert Teacher
    </h2>
    <div style={{ width: '60px', height: '4px', backgroundColor: '#FFD700', margin: '0 auto 40px' }}></div>
    
    {/* Teachers Grid */}
    <div style={{ 
      display: 'flex', 
      flexWrap: 'wrap', 
      gap: '30px', 
      justifyContent: 'center' 
    }}>
      {[
        { name: "Khurshid Akram", sub: "Mathematics Expert", exp: "25+ Yrs Exp.", img: "1" },
        { name: "Faiz Akram", sub: "All Subjects", exp: "12+ Yrs Exp.", img: "2" },
        { name: "Mohsin Akram", sub: "For Compitition", exp: "6+ Yrs Exp.", img: "3" }
      ].map((t, i) => (
        <div key={i} style={{ 
          backgroundColor: 'white', 
          padding: '30px 20px', 
          borderRadius: '15px', 
          width: '280px', 
          boxShadow: '0 8px 20px rgba(0,0,0,0.1)',
          borderBottom: '6px solid #002147',
          transition: 'transform 0.3s'
        }}>
          {/* Teacher Image */}
          <div style={{ 
            width: '120px', 
            height: '120px', 
            borderRadius: '50%', 
            margin: '0 auto 20px', 
            overflow: 'hidden', 
            border: '3px solid #FFD700',
            backgroundColor: '#eee'
          }}>
            <img 
              src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${t.img}`} 
              alt={t.name} 
              style={{ width: '100%', height: '100%', objectFit: 'cover' }} 
            />
          </div>

          {/* Teacher Info */}
          <h3 style={{ color: '#002147', fontSize: '22px', margin: '10px 0 5px' }}>{t.name}</h3>
          <p style={{ 
            color: '#FFD700', 
            backgroundColor: '#002147', 
            display: 'inline-block', 
            padding: '4px 15px', 
            borderRadius: '5px', 
            fontSize: '14px',
            fontWeight: 'bold',
            marginBottom: '10px'
          }}>
            {t.sub}
          </p>
          <p style={{ color: '#666', fontSize: '14px', margin: '0' }}>{t.exp}</p>
        </div>
      ))}
    </div>

  </div>
</div>
{/* --- ONLY TEACHERS SECTION END --- */}
    </div>
  );
}
 