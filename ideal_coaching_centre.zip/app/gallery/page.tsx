"use client";

import React from 'react';
import Link from 'next/link';

export default function GalleryPage() {
  // Yahan aap apni coaching ki photos ke URL daal sakte hain
  const photos = [
    { id: 1, title: "Classroom", url: "https://images.unsplash.com/photo-1524178232363-1fb28f74b671?q=80&w=500" },
    { id: 2, title: "Toppers 2024", url: "https://images.unsplash.com/photo-1523240715639-6f343b4f995a?q=80&w=500" },
    { id: 3, title: "Library", url: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?q=80&w=500" },
    { id: 4, title: "Prize Distribution", url: "https://images.unsplash.com/photo-1511632765486-a01980e01a18?q=80&w=500" },
    { id: 5, title: "Science Lab", url: "https://images.unsplash.com/photo-1532094349884-543bc11b234d?q=80&w=500" },
    { id: 6, title: "Annual Function", url: "https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?q=80&w=500" },
  ];

  return (
    <div style={styles.wrapper}>
      {/* Header */}
      <header style={styles.header}>
        <h1 style={styles.title}>IDEAL GALLERY</h1>
        <p style={styles.subtitle}>Glimpses of Excellence at Ideal Coaching Centre</p>
        <Link href="/" style={styles.homeLink}>← Back to Home</Link>
      </header>

      {/* Grid Layout */}
      <div style={styles.grid}>
        {photos.map((photo) => (
          <div key={photo.id} style={styles.photoCard}>
            <div style={styles.imageContainer}>
              <img src={photo.url} alt={photo.title} style={styles.image} />
            </div>
            <div style={styles.photoInfo}>
              <p style={styles.photoTitle}>{photo.title}</p>
            </div>
          </div>
        ))}
      </div>

      <footer style={styles.footer}>
        <Link href="/admission">
          <button style={styles.admissionBtn}>Join Our Batch Today</button>
        </Link>
      </footer>
    </div>
  );
}

// --- Responsive Styles ---
const styles: { [key: string]: React.CSSProperties } = {
  wrapper: { backgroundColor: '#f0f4f8', minHeight: '100vh', paddingBottom: '50px', fontFamily: 'sans-serif' },
  header: { backgroundColor: '#002147', color: 'white', padding: '60px 20px', textAlign: 'center' },
  title: { fontSize: '32px', margin: '0', color: '#FFD700' },
  subtitle: { opacity: 0.8, marginTop: '10px' },
  homeLink: { color: 'white', textDecoration: 'none', display: 'inline-block', marginTop: '15px', fontSize: '14px' },
  grid: { 
    display: 'grid', 
    gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', 
    gap: '20px', 
    padding: '40px 20px', 
    maxWidth: '1200px', 
    margin: '0 auto' 
  },
  photoCard: { 
    backgroundColor: 'white', 
    borderRadius: '12px', 
    overflow: 'hidden', 
    boxShadow: '0 4px 15px rgba(0,0,0,0.1)',
    transition: 'transform 0.3s'
  },
  imageContainer: { width: '100%', height: '220px', overflow: 'hidden' },
  image: { 
    width: '100%', 
    height: '100%', 
    objectFit: 'cover', 
    transition: 'transform 0.5s' 
  },
  photoInfo: { padding: '15px', textAlign: 'center' },
  photoTitle: { margin: '0', fontWeight: 'bold', color: '#002147' },
  footer: { textAlign: 'center', marginTop: '30px' },
  admissionBtn: { 
    backgroundColor: '#002147', 
    color: '#FFD700', 
    padding: '15px 40px', 
    borderRadius: '30px', 
    border: '2px solid #FFD700', 
    fontWeight: 'bold', 
    cursor: 'pointer',
    fontSize: '16px'
  }
};