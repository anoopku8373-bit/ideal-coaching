"use client";
import React, { useEffect, useState } from 'react';
import Link from 'next/link';

export default function StudentList() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Yahan apna Google Apps Script ka URL daalein
    const scriptURL = 'https://script.google.com/macros/s/AKfycbx0k-T73XzENIJP-pML8zlf59ovXYqaoRmxuGgylV5DrCCuN0e75dEBiCYZoO_b2K2Xug/exec';

    fetch(scriptURL)
      .then(res => res.json())
      .then(data => {
        setStudents(data);
        setLoading(false);
      })
      .catch(err => console.error("Error fetching data:", err));
  }, []);

  return (
    <div style={styles.wrapper}>
      <div style={styles.container}>
        <h1 style={styles.title}>Registered Students</h1>
        <p style={styles.subtitle}>Ideal Coaching Centre - Batch 2025-26</p>
        
        {loading ? (
          <p style={{color: 'white'}}>Loading students list...</p>
        ) : (
          <div style={styles.tableContainer}>
            <table style={styles.table}>
              <thead>
                <tr style={styles.tableHeader}>
                  <th>Name</th>
                  <th>Class</th>
                  <th>Mobile (Hidden)</th>
                </tr>
              </thead>
              <tbody>
                {students.map((s, index) => (
                  <tr key={index} style={styles.tableRow}>
                    <td>{s.name}</td>
                    <td>{s.studentClass}</td>
                    <td>{s.mobile.substring(0, 5)}*****</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        
        <Link href="/" style={styles.backBtn}>Back to Home</Link>
      </div>
    </div>
  );
}

const styles = {
  wrapper: { backgroundColor: '#002147', minHeight: '100vh', padding: '40px 20px', fontFamily: 'sans-serif' },
  container: { maxWidth: '800px', margin: '0 auto', textAlign: 'center' as const },
  title: { color: '#FFD700', fontSize: '28px', marginBottom: '10px' },
  subtitle: { color: '#ffffff', opacity: 0.8, marginBottom: '30px' },
  tableContainer: { backgroundColor: 'white', borderRadius: '12px', overflow: 'hidden', boxShadow: '0 10px 30px rgba(0,0,0,0.3)' },
  table: { width: '100%', borderCollapse: 'collapse' as const },
  tableHeader: { backgroundColor: '#FFD700', color: '#002147', textAlign: 'left' as const },
  tableRow: { borderBottom: '1px solid #eee', textAlign: 'left' as const, color: '#333' },
  backBtn: { display: 'inline-block', marginTop: '30px', color: '#FFD700', textDecoration: 'none', fontWeight: 'bold' }
};

// Table padding fix for cells
// Styles mein table th/td ko 15px padding dena mat bhulna