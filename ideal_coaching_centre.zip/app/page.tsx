export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <nav className="flex items-center justify-between p-6 bg-blue-700 text-white shadow-lg">
      <h1 className="text-3xl font-black tracking-tighter uppercase italic">
  <span className="bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
    Ideal COACHING CENTRE
  </span>
</h1>
<div className="space-x-6">
  {/* अब यह लिंक आपको /welcome वाले पेज पर ले जाएगा */}
  <a href="/home" className="hover:text-yellow-400">Home</a>
  <a href="/admission" className="hover:text-yellow-400">Admission</a>
  <a href="gallery" className="hover:text-yellow-400">Gallery</a>
  <a href="student" className="hover:text-yellow-400">Student</a>
</div>
      </nav>

      {/* Hero Section */}
      <main className="flex flex-col items-center justify-center mt-20 px-4 text-center">
        <h2 className="text-5xl font-extrabold text-gray-800">
        "Success is a journey, not a destination"
        </h2>
        <p className="mt-4 text-lg text-gray-600 max-w-2xl">
        ("सफलता एक यात्रा है, गंतव्य नहीं")
        </p>
        <button className="mt-8 bg-blue-600 text-white px-8 py-3 rounded-full font-bold hover:bg-blue-800 transition">
          एडमिशन के लिए संपर्क करें
        </button>
        {/* 3 Pillars Section: अनुशासन, सच्चरित्रता, सफलता */}
<section className="py-20 bg-gray-50">
<div className="text-center mb-16">
  {/* यहाँ दोनों शब्दों को एक ही रंग (Blue) में रखा गया है */}
  <h3 className="text-4xl font-bold text-blue-700 tracking-tight">
    हमारे मूल मंत्र
  </h3>
  <div className="h-1 w-20 bg-blue-600 mx-auto mt-4 rounded-full"></div>
    
    <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
      
      {/* Pillar 1: अनुशासन */}
      <div className="group p-10 bg-white rounded-3xl shadow-sm hover:shadow-2xl transition-all duration-300 border border-gray-100 text-center">
        <div className="w-20 h-20 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center mx-auto mb-6 text-3xl group-hover:bg-blue-700 group-hover:text-white transition-colors">
          ⚖️
        </div>
        <h4 className="text-2xl font-black text-gray-800 mb-4">अनुशासन !</h4>
        <p className="text-gray-600 leading-relaxed">
          नियमों का पालन और समय की कद्र ही सफलता की पहली सीढ़ी है। हम एक अनुशासित वातावरण सुनिश्चित करते हैं।
        </p>
      </div>

      {/* Pillar 2: सच्चरित्रता */}
      <div className="group p-10 bg-white rounded-3xl shadow-sm hover:shadow-2xl transition-all duration-300 border border-gray-100 text-center">
        <div className="w-20 h-20 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center mx-auto mb-6 text-3xl group-hover:bg-blue-700 group-hover:text-white transition-colors">
          💎
        </div>
        <h4 className="text-2xl font-black text-gray-800 mb-4">सच्चरित्रता !</h4>
        <p className="text-gray-600 leading-relaxed">
          सिर्फ शिक्षा ही नहीं, हम नैतिक मूल्यों और अच्छे चरित्र का निर्माण करते हैं, जो जीवन भर साथ निभाता है।
        </p>
      </div>

      {/* Pillar 3: सफलता */}
      <div className="group p-10 bg-white rounded-3xl shadow-sm hover:shadow-2xl transition-all duration-300 border border-gray-100 text-center">
        <div className="w-20 h-20 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center mx-auto mb-6 text-3xl group-hover:bg-blue-700 group-hover:text-white transition-colors">
          🎯
        </div>
        <h4 className="text-2xl font-black text-gray-800 mb-4">सफलता !</h4>
        <p className="text-gray-600 leading-relaxed">
          जब अनुशासन और चरित्र मिलते हैं, तो सफलता सुनिश्चित हो जाती है। हमारा लक्ष्य हर छात्र की जीत है।
        </p>
      </div>

    </div>
  </div>
</section>
{/* --- SCROLLING NEWS SECTION START --- */}
<div style={{ 
  backgroundColor: '#FFD700', // Pila rang
  color: '#002147',          // Navy Blue rang
  padding: '12px 0', 
  fontWeight: 'bold', 
  fontSize: '18px', 
  borderBottom: '2px solid #002147',
  boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
}}>
  <marquee scrollamount="10" behavior="scroll" direction="left">
    📢 New Batch Starting for Class 10th & 12th from Feb 1st! &nbsp;&nbsp;&nbsp;&nbsp;  
    📍 Address: Ideal Coaching, Harpur Karah, Bnaiyapur. &nbsp;&nbsp;&nbsp;&nbsp;
    📞 Call for details:9708119924,9065585556
  </marquee>
</div>
{/* --- SCROLLING NEWS SECTION END --- */}
      </main>
    </div>
  );
}
  