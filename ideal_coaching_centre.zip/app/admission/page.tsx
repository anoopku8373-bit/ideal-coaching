"use client";

import React, { useState } from 'react';
import Link from 'next/link';

export default function AdmissionPage() {
  const [formData, setFormData] = useState({ name: '', studentClass: '', mobile: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const scriptURL = 'https://script.google.com/macros/s/AKfycbwQWDVBWLwWOeafLEV2jQYGdwxokhPXM8knUYY3DCHZprj0WxK0QqX0AINtaDwo7xqh8w/exec'; 

    try {
      await fetch(scriptURL, {
        method: 'POST',
        mode: 'no-cors',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      alert(`Success! ${formData.name}, your form is submitted.`);
      setFormData({ name: '', studentClass: '', mobile: '' });
    } catch (error) {
      alert("Error! Please check your connection.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.wrapper}>
      <div style={styles.card}>
        <div style={styles.header}>
          <h1 style={styles.title}>IDEAL COACHING CENTRE</h1>
          <div style={styles.divider}></div>
        </div>

        <h2 style={styles.formHeading}>Admission Form 2025-26</h2>

        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.inputGroup}>
            <label style={styles.label}>Student Name</label>
            <input 
              type="text" 
              placeholder="Type your name..." 
              required 
              style={styles.input}
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Select Class</label>
            <select 
              style={styles.input}
              required
              value={formData.studentClass}
              onChange={(e) => setFormData({...formData, studentClass: e.target.value})}
            >
              <option value="">-- Click to Choose --</option>
              <option value="9th">Class 9th</option>
              <option value="10th">Class 10th</option>
              <option value="11th">Class 11th</option>
              <option value="12th">Class 12th</option>
            </select>
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Mobile Number</label>
            <input 
              type="tel" 
              placeholder="Type your number..." 
              required 
              style={styles.input}
              value={formData.mobile}
              onChange={(e) => setFormData({...formData, mobile: e.target.value})}
            />
          </div>

          <button type="submit" disabled={loading} style={styles.button}>
            {loading ? 'Submitting...' : 'SUBMIT DATA'}
          </button>
        </form>

        <Link href="/" style={styles.backLink}>← Back to Home</Link>
      </div>
    </div>
  );
}

const styles: { [key: string]: React.CSSProperties } = {
  wrapper: { display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', backgroundColor: '#002147', padding: '20px', fontFamily: 'sans-serif' },
  card: { background: '#ffffff', padding: '30px', borderRadius: '15px', width: '100%', maxWidth: '400px', textAlign: 'center' as const, borderTop: '8px solid #FFD700' },
  header: { marginBottom: '20px' },
  title: { color: '#002147', fontSize: '22px', fontWeight: 'bold', margin: '0' },
  divider: { width: '40px', height: '3px', backgroundColor: '#FFD700', margin: '10px auto' },
  formHeading: { fontSize: '18px', color: '#333', marginBottom: '20px' },
  form: { display: 'flex', flexDirection: 'column' as const },
  inputGroup: { textAlign: 'left' as const, marginBottom: '15px' },
  label: { display: 'block', fontSize: '13px', fontWeight: 'bold', color: '#002147', marginBottom: '4px' },
  input: { 
    width: '100%', 
    padding: '12px', 
    borderRadius: '6px', 
    border: '2px solid #ddd', 
    fontSize: '16px', 
    boxSizing: 'border-box' as const,
    color: '#000000', // YAHAN FIX KIYA HAI - TEXT AB BLACK DIKHEGA
    backgroundColor: '#ffffff' 
  },
  button: { marginTop: '10px', padding: '14px', backgroundColor: '#FFD700', color: '#002147', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold', fontSize: '16px' },
  backLink: { marginTop: '20px', display: 'inline-block', color: '#002147', textDecoration: 'none', fontSize: '14px', fontWeight: 'bold' }
};